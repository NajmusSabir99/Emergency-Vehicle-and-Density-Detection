# Vehicle detc. > 2025-01-07 10:43pm
https://universe.roboflow.com/emergency-vehicle-detection-sabir/vehicle-detc.

Provided by a Roboflow user
License: CC BY 4.0

