from ultralytics import YOLO
import cv2
import requests
import time


def main():
    # Load the YOLO model
    model = YOLO("Desktop/save_model_yolov9_sabir.pt")
    api_url = "http://192.168.28.192:8080"  # API endpoint
    video_url = "http://192.168.28.192:8080/video_feed"  # Video feed URL

    # Open the video stream
    cap = cv2.VideoCapture(video_url)
    if not cap.isOpened():
        print("Error: Could not open video stream.")
        return

    # Thresholds and state variables
    threshold = 3  # Number of consecutive frames required
    is_on = False
    consecutive_detections = 0
    frame_counter = 0  # To track frames
    prev_time = time.time()  # For FPS calculation
    last_object_count_time = time.time()  # For object count interval
    total_object_count = 0  # Initialize total object count

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to read frame.")
            break

        # Measure time for FPS calculation
        current_time = time.time()
        fps = 1 / (current_time - prev_time)
        prev_time = current_time

        # Process every 3rd frame
        frame_counter += 1

        if frame_counter % 3 == 0:
            # YOLO detection
            results = model(frame)
            detected = False
            total_object_count = 0  # Reset object count for this frame

            for result in results:
                for box in result.boxes:
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    confidence = float(box.conf[0])
                    if confidence < 0.65:
                        continue

                    cls = int(box.cls[0])
                    label = model.names[cls]

                    # Count all detected objects
                    total_object_count += 1

                    # Draw bounding box and label
                    color = (0, 255, 0)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    cv2.putText(
                        frame,
                        f"{label} {confidence:.2f}",
                        (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        color,
                        2,
                    )

                    # Specific detection logic (if required for other parts)
                    if label in ["fire-truck", "ambulance"]:
                        detected = True

            # Update consecutive detection count
            if detected:
                consecutive_detections += 1
            else:
                consecutive_detections = 0

            # Send API requests based on detection count
            if consecutive_detections >= threshold and not is_on:
                try:
                    response = requests.get(f"{api_url}/on")
                    print(f"API Request ON: {response.status_code}")
                except requests.RequestException as error:
                    print(f"API request error: {error}")
                is_on = True
            elif consecutive_detections < threshold and is_on:
                try:
                    response = requests.get(f"{api_url}/off")
                    print(f"API Request OFF: {response.status_code}")
                except requests.RequestException as error:
                    print(f"API request error: {error}")
                is_on = False

        # Send total object count every 5 seconds
        if current_time - last_object_count_time >= 5:
            try:
                response = requests.get(f"{api_url}/count={total_object_count}")
                print(f"Total object count sent: {total_object_count}, Status Code: {response.status_code}")
                last_object_count_time = current_time
            except requests.RequestException as error:
                print(f"Error sending object count: {error}")

        # Display total object count and FPS
        cv2.putText(
            frame,
            f"Objects: {total_object_count}",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (255, 0, 0),
            2,
        )
        cv2.putText(
            frame,
            f"FPS: {fps:.2f}",
            (10, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 255, 0),
            2,
        )

        # Show the frame
        cv2.imshow("YOLO Live Detection", frame)

        # Exit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    # Cleanup
    cap.release()
    cv2.destroyAllWindows()


# Run the program
if __name__ == "__main__":
    main()
