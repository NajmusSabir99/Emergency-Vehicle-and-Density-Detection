from ultralytics import YOLO
import cv2
import asyncio
import httpx

# Load the YOLO model
model = YOLO("Desktop/save_model_yolov9_sabir.pt")  
url = "http://192.168.28.192:8080"  # API endpoint

# Open the webcam
cap = cv2.VideoCapture(1)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Initialize variables
consecutive_fire_or_ambulance = 0  # Counter for consecutive frames
threshold = 3  # Number of consecutive frames required for "on" request
is_on = False  # Tracks the current state of the system


async def send_request(state):
    """Send async request to the API."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{url}/{state}")
            print(f"Sent {state} request: {response.status_code}")
        except httpx.RequestError as e:
            print(f"An error occurred while sending {state} request: {e}")


async def main_loop():
    global consecutive_fire_or_ambulance, is_on
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to read frame from webcam.")
            break

        # Resize frame for the YOLO model
        resized_frame = cv2.resize(frame, (416, 416))
        results = model(resized_frame)

        # Initialize variables for current frame
        detected_fire_or_ambulance = False
        object_count = 0  # Object count initialization

        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  
                confidence = float(box.conf[0]) 
                
                # Skip detections with confidence < 60%
                if confidence < 0.6:
                    continue
                
                cls = int(box.cls[0])  
                label = model.names[cls]  

                # Draw bounding box
                color = (0, 255, 0)
                scale_x = frame.shape[1] / 416  
                scale_y = frame.shape[0] / 416 
                x1 = int(x1 * scale_x)
                x2 = int(x2 * scale_x)
                y1 = int(y1 * scale_y)
                y2 = int(y2 * scale_y)

                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)  
                cv2.putText(
                    frame,
                    f"{label} {confidence:.2f}",
                    (x1, y1 - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    color,
                    2,
                )

                # Count detected fire-truck or ambulance objects
                if label == 'fire-truck' or label == 'ambulance':
                    detected_fire_or_ambulance = True
                object_count += 1  # Increment object count for each detection

        # Update consecutive detection counter
        if detected_fire_or_ambulance:
            consecutive_fire_or_ambulance += 1
        else:
            consecutive_fire_or_ambulance = 0

        # Send requests based on consecutive frames and current state
        if consecutive_fire_or_ambulance >= threshold and not is_on:
            await send_request("on")
            is_on = True
        elif consecutive_fire_or_ambulance < threshold and is_on:
            await send_request("off")
            is_on = False

        # Display object count in the top-left corner
        cv2.putText(
            frame,
            f"Objects: {object_count}",
            (10, 30),  # Position of the text in the top-left corner
            cv2.FONT_HERSHEY_SIMPLEX,
            1,  # Font size
            (255, 0, 0),  # Text color (Blue)
            2  # Thickness of the text
        )

        # Show bounding boxes and object count
        cv2.imshow("YOLO Live Detection", frame)

        # Break the loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break


# Run the main loop
try:
    asyncio.run(main_loop())
finally:
    # Release resources
    cap.release()
    cv2.destroyAllWindows()