from gpiozero import LED
from time import sleep
from flask import Flask
#mode
# Define LEDs for each lane
red1 = LED(14)    # Lane 1
yellow1 = LED(15)
green1 = LED(18)

red2 = LED(23)    # Lane 2
yellow2 = LED(24)
green2 = LED(25)

red3 = LED(5)     # Lane 3
yellow3 = LED(6)
green3 = LED(13)

app = Flask(_name_)

# Initial state: All lanes red
def all_red():
    red1.on()
    yellow1.off()
    green1.off()

    red2.on()
    yellow2.off()
    green2.off()

    red3.on()
    yellow3.off()
    green3.off()

    print("Initial State: All lanes red.")

# Default to all lanes red initially
all_red()

# Priority flag
priority_mode = False

# Vehicle count for Lane 1
vehicle_count_lane1 = 0  # Initialize to 0

# Normal traffic light cycle for three lanes
def traffic_cycle():
    while True:
        if not priority_mode:
            # Lane 1 green
            print("Lane 1: Green ON, Red OFF")
            green1.on()
            red1.off()
            if vehicle_count_lane1 > 4:
                print(f"Lane 1: High density detected ({vehicle_count_lane1} vehicles). Extending green duration.")
                sleep(15)  # Tripled delay for high density
            else:
                sleep(5)  # Normal delay
            print("Lane 1: Green OFF, Yellow ON")
            green1.off()
            yellow1.on()
            sleep(2)
            print("Lane 1: Yellow OFF, Red ON")
            yellow1.off()
            red1.on()

            # Lane 2 green
            print("Lane 2: Green ON, Red OFF")
            green2.on()
            red2.off()
            sleep(5)
            print("Lane 2: Green OFF, Yellow ON")
            green2.off()
            yellow2.on()
            sleep(2)
            print("Lane 2: Yellow OFF, Red ON")
            yellow2.off()
            red2.on()

            # Lane 3 green
            print("Lane 3: Green ON, Red OFF")
            green3.on()
            red3.off()
            sleep(5)
            print("Lane 3: Green OFF, Yellow ON")
            green3.off()
            yellow3.on()
            sleep(2)
            print("Lane 3: Yellow OFF, Red ON")
            yellow3.off()
            red3.on()
        else:
            sleep(1)  # Keep waiting until priority mode is turned off

# Flask route to activate priority for Lane 1
@app.route("/on")
def lane_on():
    global priority_mode
    priority_mode = True

    # Grant priority to Lane 1
    red1.off()
    yellow1.off()
    green1.on()
    print("Priority Mode: Lane 1 Green ON, Other Lanes Red")

    # Other lanes stay red
    red2.on()
    yellow2.off()
    green2.off()

    red3.on()
    yellow3.off()
    green3.off()

    return "Priority mode activated for Lane 1"

# Flask route to deactivate priority and return to normal cycle
@app.route("/off")
def lane_off():
    global priority_mode
    priority_mode = False

    # Transition Lane 1 to red
    print("Disabling Priority Mode: Lane 1 Green OFF, Yellow ON")
    yellow1.on()
    green1.off()
    sleep(2)
    print("Lane 1: Yellow OFF, Red ON")
    yellow1.off()
    red1.on()

    return "Priority mode deactivated. Returning to normal operation."

# Flask route to update vehicle count on Lane 1
@app.route("/update_lane1/<int:count>")
def update_vehicle_count_lane1(count):
    global vehicle_count_lane1
    vehicle_count_lane1 = count
    print(f"Vehicle count for Lane 1 updated to: {vehicle_count_lane1}")
    return f"Vehicle count for Lane 1 is now {vehicle_count_lane1}"

# Start traffic light control in a background thread
import threading
traffic_thread = threading.Thread(target=traffic_cycle)
traffic_thread.daemon = True
traffic_thread.start()

if_name_ == "_main_":
    app.run(host="0.0.0.0",port=8080)