import cv2
import time

# URL of the video feed
url = "http://192.168.31.43:5000/video_feed"

# Open the video stream
cap = cv2.VideoCapture(url)

# Check if the video stream is opened correctly
if not cap.isOpened():
    raise IOError("Cannot open video stream")

# Frame rate calculation initialization
fps = 0
frame_count = 0
start_time = time.time()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Calculate and display FPS
    frame_count += 1
    if frame_count >= 10:
        end_time = time.time()
        fps = frame_count / (end_time - start_time)
        frame_count = 0
        start_time = time.time()

    # Overlay the FPS on the frame
    cv2.putText(frame, f'FPS: {fps:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)

    # Display the frame
    cv2.imshow('Video Stream', frame)

    # Break the loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video stream and close the window
cap.release()
cv2.destroyAllWindows()